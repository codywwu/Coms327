#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>

typedef struct foo{
    char Map[21][80];
    int pathLength;
    int path[2][205];
    int w;int e;
    int n;int s;
}   foo_t;

void printMapStruct(foo_t *f){
    for(int i = 0; i<21; i++){
        for(int ii = 0; ii<80; ii++){
            printf("%c", f->Map[i][ii]);
        }
    printf("\n");
    }  
    printf("\n\n\n");
}
void GenRocks_and_trees(foo_t *f){
    int h; int l; int x; int y; int sw; int poss; char Rock = '%'; char Tree = '^';
    for(int i = 0; i<5; i++){
        h = rand() % 10 + 6; l = rand() % 10 + 6;
        int rangeX = 79 - l; int rangeY = 20 - h;
        x = rand() % rangeX; y = rand() % rangeY;
        for(int j = y; j<= y+h; j++){
            for(int k = x; k<= x+l; k++){
                if(f->Map[j][k] == '.' || f->Map[j][k] == ':'){
                    poss = rand() % 100;
                    if(poss<25){
                        sw = rand() % 2;
                        if(sw == 0){
                            f->Map[j][k] = Rock;
                        }else{
                            f->Map[j][k] = Tree;
                        }
                    }
                }
            }
        }
    }
}


void GenCenter_and_Mart(foo_t *f,double prob){
    int x; int y; int Location;

    srand(time(NULL));
  int Cnum = rand()%100+1;
  int Cp;
  Cp = 100*prob;
  if(Cnum<Cp || prob == 101){
    for(int i = 0; i<2; i++){
        char building;
        if(i == 0){ building = 'C';} else{ building = 'M';}
        while (1==1){
            Location = rand() % f->pathLength;
            x = f->path[0][Location]; y = f->path[1][Location];
            while(x <= 5 || x >= 74 || y <= 3 || y >= 17){
                    Location = rand() % f->pathLength;
                    x = f->path[0][Location]; y = f->path[1][Location];
            }
            if((f->Map[y][x-2] == ':' || f->Map[y][x-2] == '.') && (f->Map[y][x-1] == ':' || f->Map[y][x-1] == '.')){
                if((f->Map[y-1][x-2] == ':' || f->Map[y-1][x-2] == '.') && (f->Map[y-1][x-1] == ':' || f->Map[y-1][x-1] == '.')){
                    f->Map[y][x-2] = building; f->Map[y][x-1] = building;
                    f->Map[y-1][x-2] = building; f->Map[y-1][x-1] = building;
                    break;
                }else if((f->Map[y+1][x-2] == ':' || f->Map[y+1][x-2] == '.') && (f->Map[y+1][x-1] == ':' || f->Map[y+1][x-1] == '.')){
                    f->Map[y][x-2] = building; f->Map[y][x-1] = building;
                    f->Map[y+1][x-2] = building; f->Map[y+1][x-1] = building;
                    break;
                }
            }else if((f->Map[y][x+2] == ':' || f->Map[y][x+2] == '.') && (f->Map[y][x+1] == ':' || f->Map[y][x+1] == '.')){
                if((f->Map[y-1][x+2] == ':' || f->Map[y-1][x+2] == '.') && (f->Map[y-1][x+1] == ':' || f->Map[y-1][x+1] == '.')){
                    f->Map[y][x+2] = building; f->Map[y][x+1] = building;
                    f->Map[y-1][x+2] = building; f->Map[y-1][x+1] = building;
                    break;
                }else if((f->Map[y+1][x+2] == ':' || f->Map[y+1][x+2] == '.') && (f->Map[y+1][x+1] == ':' || f->Map[y+1][x+1] == '.')){
                    f->Map[y][x+2] = building; f->Map[y][x+1] = building;
                    f->Map[y+1][x+2] = building; f->Map[y+1][x+1] = building;
                    break;
                }
            }
            else if((f->Map[y+1][x] == ':' || f->Map[y+1][x] == '.') && (f->Map[y+2][x] == ':' || f->Map[y+2][x] == '.')){
                if((f->Map[y+1][x-1] == ':' || f->Map[y+1][x-1] == '.') && (f->Map[y+2][x-1] == ':' || f->Map[y+2][x-1] == '.')){
                    f->Map[y+1][x] = building; f->Map[y+2][x] = building;
                    f->Map[y+1][x-1] = building; f->Map[y+2][x-1] = building;
                    break;
                }else if((f->Map[y+1][x+1] == ':' || f->Map[y+1][x+1] == '.') && (f->Map[y+2][x+1] == ':' || f->Map[y+2][x+1] == '.')){
                    f->Map[y+1][x] = building; f->Map[y+2][x] = building;
                    f->Map[y+1][x+1] = building; f->Map[y+2][x+1] = building;
                    break;
                }
            }
            else if((f->Map[y-1][x] == ':' || f->Map[y-1][x] == '.') && (f->Map[y-2][x] == ':' || f->Map[y-2][x] == '.')){
                if((f->Map[y-1][x-1] == ':' || f->Map[y-1][x-1] == '.') && (f->Map[y-2][x-1] == ':' || f->Map[y-2][x-1] == '.')){
                    f->Map[y-1][x] = building; f->Map[y-2][x] = building;
                    f->Map[y-1][x-1] = building; f->Map[y-2][x-1] = building;
                    break;
                }else if((f->Map[y-1][x+1] == ':' || f->Map[y-1][x+1] == '.') && (f->Map[y-2][x+1] == ':' || f->Map[y-2][x+1] == '.')){
                    f->Map[y-1][x] = building; f->Map[y-2][x] = building;
                    f->Map[y-1][x+1] = building; f->Map[y-2][x+1] = building;
                    break;
                }
            }
        }
    }
}
}

// N S E W 
int *ChechNeighbor(foo_t *world[400][400],int y, int x){

    int n, s, w, e;
    int * arry = malloc(sizeof(int) * 4);
    if(world[y-1][x]!= NULL){ // north
        // checking if north of empty cell is not null
      
        //if it is not null, we are settign the north of the current cell to the south of the existing cell to the northy
        n = world[y-1][x]->s;
        
    }else{
        n =rand()%75+5;
       
    }

    if(world[y+1][x]!=NULL){// s->n
         s= world[y+1][x]->n;
    
    }else{
        s =rand()%75+5;
       
    }

    if(world[y][x+1]!=NULL){// e
        e = world[y][x+1]->w;
    
    }else{
         e =rand()%15+5;
         
    }

    if(world[y][x-1]!=NULL){// w
        w = world[y][x-1]->e;

    }else{
         w =rand()%15+5;
        
    }

    arry[0]=n;
    arry[1]=s;
    arry[2]=e;
    arry[3]=w;
    
    

return arry;
}
// 
void GenPath(foo_t *f, int n, int s, int e, int w){
    
    int N = n; int S =s;
    int W = w; int E = e;
    int x = rand() % 15 + 3; int y = rand() % 70 + 5;
    f -> pathLength = 0;


    for(int i = 0; i<=x; i++){
        f -> Map[i][N] = '#';
        f -> path[0][f->pathLength] = N; f -> path[1][f->pathLength] = i; 
        f -> pathLength++;
    }
    for(int i = 20; i>=x; i--){
        f -> Map[i][S] = '#';
        f -> path[0][f->pathLength] = S; f -> path[1][f->pathLength] = i; 
        f -> pathLength++;
    }
    if(N<=S){
        for(int i = N; i<=S; i++){
             f -> Map[x][i] = '#';
             f -> path[0][f->pathLength] = i; f -> path[1][f->pathLength] = x; 
             f -> pathLength++;
        }
    }else{
        for(int i = S; i<=N; i++){
             f -> Map[x][i] = '#';
             f -> path[0][f->pathLength] = i; f -> path[1][f->pathLength] = x; 
             f -> pathLength++;
        }
    }
    for(int i = 0; i<=y; i++){
        f -> Map[W][i] = '#';
        f -> path[0][f->pathLength] = i; f -> path[1][f->pathLength] = W; 
        f -> pathLength++;
    }
    for(int i = 79; i>=y; i--){
        f -> Map[E][i] = '#';
        f -> path[0][f->pathLength] = i; f -> path[1][f->pathLength] = E; 
        f -> pathLength++;
    }
    if(W<=E){
        for(int i = W; i<=E; i++){
             f -> Map[i][y] = '#';
             f -> path[0][f->pathLength] = y; f -> path[1][f->pathLength] = i; 
             f -> pathLength++;
        }
    }else{
        for(int i = E; i<=W; i++){
             f -> Map[i][y] = '#';
             f -> path[0][f->pathLength] = y; f -> path[1][f->pathLength] = i; 
             f -> pathLength++;
        }
    }

}


void GenGrass_2(foo_t *f, int x, int y, int i){
    if(f -> Map[y][x] == '.'){
        int ran = rand() % 70 + i;
        if(ran < 72){
            f -> Map[y][x] = ':';
            GenGrass_2(f, x+1, y, i+1);
            GenGrass_2(f, x-1, y, i+1);
            GenGrass_2(f, x, y+1, i+1);
            GenGrass_2(f, x, y-1, i+1);
        }
    }
}


void GenGrass_1(foo_t *f, int i){
    if(i == 0){
        int x = rand() % 25 + 10; int y = rand() % 7 + 2; GenGrass_2(f, x, y, 0);
    }else if(i == 1){
        int x = rand() % 25 + 45; int y = rand() % 7 + 2; GenGrass_2(f, x, y, 0);
    }else if(i == 2){
        int x = rand() % 25 + 45; int y = rand() % 7 + 12; GenGrass_2(f, x, y, 0);
    }else{
        int x = rand() % 25 + 10; int y = rand() % 7 + 12; GenGrass_2(f, x, y, 0);
    }
}


void GenGrass(foo_t *f){
    int i = rand() % 4;
    int ii = rand() % 4;
    while(i == ii){
        ii = rand() % 4;
    }
    GenGrass_1(f,i);
    GenGrass_1(f,ii);
}


 void GenBoulder(foo_t *f){
    for(int i = 0; i<80; i++){
        f -> Map[0][i] = '%';
        f -> Map[20][i] = '%';
    }
    for(int i = 1; i<20; i++){
        f -> Map[i][0] = '%';
        f -> Map[i][79] = '%';
    }
    
}

foo_t *GMap(double prob, int n, int s, int e, int w){
   srand(time(NULL));
     foo_t *f= malloc(sizeof(foo_t));
     f->n = n;
     f->s = s;
     f->e = e;
     f->w = w;
    for(int i = 0; i<21; i++){
        for(int ii = 0; ii<80; ii++){
            f->Map[i][ii] = '.';
        }
    }

    
    GenBoulder(f);
    GenGrass(f);
    GenPath(f, n, s, e, w);
    GenCenter_and_Mart(f,prob);
    GenRocks_and_trees(f);
   return f;
}

double probability(int y, int x){
  // manhadon distance: |x1-x2| + |y1-y2|
  double d;
  d = (abs(199-y)+abs(199-x));
  
  double res;
  res = (((-45*d)/200)+50)/100;
  return res;
}

int main()
{
    int w,s,n,e;
    int Wx,Wy;
    Wx = 199;
    Wy= 199;
    double prob;
    prob =probability(Wx,Wy);
    srand(time(NULL));
    
    foo_t *world[400][400];
 
    // // store the middle inide the World;

    world[199][199] = malloc(sizeof(foo_t));
    ChechNeighbor(world,Wy,Wx);

    world[Wy][Wx]->n = rand()%75+5;     
    world[Wy][Wx]->s = rand()%75+5;
    world[Wy][Wx]->e = rand()%15+5;
    world[Wy][Wx]->w = rand()%15+5;

    
    world[199][199] = GMap(101,world[Wy][Wx]->n,world[Wy][Wx]->s,world[Wy][Wx]->e,world[Wy][Wx]->w);

     printMapStruct(world[199][199]);
    printf("This is Map %d  %d \n", Wx,Wy);
     char ch;
while(1){
    
    scanf("%c",&ch);
    if(ch == 'w'){
        Wx--;
        if((0 < Wx && Wx<400) || (0< Wy && Wy < 400)){
             
          // next step is Empty    
        if(world[Wy][Wx] == NULL ){

            world[Wy][Wx] = malloc(sizeof(foo_t));
           
            int* arry = ChechNeighbor(world,Wy,Wx);
             prob =probability(Wx,Wy);
            world[Wy][Wx] = GMap(prob, arry[0],arry[1],arry[2],arry[3]);
            


            printMapStruct(world[Wy][Wx]);
            
        }else{
        
            printMapStruct(world[Wy][Wx]);

        }
        
         printf("This is Map %d  %d \n", Wy,Wx);
         }else{
             printf("You are getting out of the world");
         }

    }else if(ch == 'e'){
        
        Wx++;
         if((0 < Wx && Wx<400) || (0< Wy && Wy < 400)){
         
        if(world[Wy][Wx] == NULL ){
             world[Wy][Wx] = malloc(sizeof(foo_t));
            int* arry = ChechNeighbor(world,Wy,Wx);
             prob =probability(Wx,Wy);
             world[Wy][Wx] = GMap(prob, arry[0],arry[1],arry[2],arry[3]);
           
            printMapStruct(world[Wy][Wx]);
        }else{
             
            printMapStruct(world[Wy][Wx]);
        }
         printf("This is Map %d  %d \n", Wy,Wx);
         }else{
             printf("You are getting out of the world");
         }
    }else if(ch == 's' ){
        Wy++;
         if((0 < Wx && Wx<400) || (0< Wy && Wy < 400)){
        if(world[Wy][Wx] == NULL){
             world[Wy][Wx] = malloc(sizeof(foo_t));
             ChechNeighbor(world,Wy,Wx);

           int* arry = ChechNeighbor(world,Wy,Wx);
             prob =probability(Wx,Wy);
            world[Wy][Wx] = GMap(prob, arry[0],arry[1],arry[2],arry[3]);    

            printMapStruct(world[Wy][Wx]);
        }else{
             
            printMapStruct(world[Wy][Wx]);
        }
         printf("This is Map %d  %d \n", Wy,Wx);
         }else{
              printf("You are getting out of the world");
         }
    }else if(ch == 'n'){
        Wy--;
        if((0 < Wx && Wx<400) || (0< Wy && Wy < 400)){
        if(world[Wy][Wx] == NULL){
             
          world[Wy][Wx] = malloc(sizeof(foo_t));
           
            int* arry = ChechNeighbor(world,Wy,Wx);
             prob =probability(Wx,Wy);
            world[Wy][Wx] = GMap(prob, arry[0],arry[1],arry[2],arry[3]);
         
            
        
            printMapStruct(world[Wy][Wx]);
        }else{
             
            printMapStruct(world[Wy][Wx]);
        }
         printf("This is Map %d  %d \n", Wy,Wx);
        }else{
            printf("You are getting out of the world");
        }
    }else if(ch == 'q'){
        printf("End\n");
        break; 
    }else if(ch == 'f' ){
        scanf("%d %d",&Wy,&Wx);
        if((0 < Wx && Wx<400) || (0< Wy && Wy < 400)){
            // world[Wy][Wx]->n = rand()%70 +5;
            // world[Wy][Wx]->s = rand()%70 +5;
            // world[Wy][Wx]->w =rand()%15+5;
            // world[Wy][Wx]->e= rand()%15+5;

         if(world[Wy][Wx] == NULL){
            world[Wy][Wx] = malloc(sizeof(foo_t));
           
            int* arry = ChechNeighbor(world,Wy,Wx);
             prob =probability(Wx,Wy);
            world[Wy][Wx] = GMap(prob, arry[0],arry[1],arry[2],arry[3]);
            printMapStruct(world[Wy][Wx]);
        }else{
            printMapStruct(world[Wy][Wx]);
        }
         printf("This is Map %d  %d \n", Wy,Wx);
    }else{
        printf(" please enter a valid value\n");
    }
    }
}
return 0;
}